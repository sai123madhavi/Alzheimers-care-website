const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

// Word list for the game
const words = ['javascript', 'python', 'html', 'css', 'developer', 'frontend', 'backend'];

// Function to shuffle letters in a word
function shuffleWord(word) {
  const shuffled = word.split('').sort(() => Math.random() - 0.5).join('');
  return shuffled;
}

// API endpoint to get a jumbled word
app.get('/game/word', (req, res) => {
  const randomWord = words[Math.floor(Math.random() * words.length)];
  const jumbledWord = shuffleWord(randomWord);
  res.json({ word: randomWord, jumbled: jumbledWord });
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
